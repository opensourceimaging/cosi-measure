#ifndef _COMM_H
#define _COMM_H


extern int comm_init( void);


#endif
