#include "version.h"

const char* mendel_date = MENDEL_DATE;
const int   mendel_version = MENDEL_VERSION;
const int   mendel_build = MENDEL_BUILD;
