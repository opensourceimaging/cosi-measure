#include	"debug.h"

volatile uint32_t debug_flags = DEBUG_INIT;

