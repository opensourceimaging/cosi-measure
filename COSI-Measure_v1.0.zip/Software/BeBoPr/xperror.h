
#include <stdarg.h>

extern void xperror( const char* format, ...);
