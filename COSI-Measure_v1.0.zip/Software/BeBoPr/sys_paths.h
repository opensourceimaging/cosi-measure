#ifndef _SYS_PATHS_H
#define _SYS_PATHS_H

#include <dirent.h>

extern const char* sys_path_finder( char* buffer, size_t max_size, const char* path);

#endif
