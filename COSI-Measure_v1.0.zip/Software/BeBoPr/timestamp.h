#ifndef _TIMESTAMP_H
#define _TIMESTAMP_H

extern void timestamp_init( void);
extern double timestamp_get( void);

#endif
