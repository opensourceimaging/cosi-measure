/* This is a generated file, any changes will be overwritten */
#define MENDEL_VERSION	1
#define MENDEL_BUILD	1060
#define MENDEL_DATE	"Thu 09-03-2017 20:00 UTC"
